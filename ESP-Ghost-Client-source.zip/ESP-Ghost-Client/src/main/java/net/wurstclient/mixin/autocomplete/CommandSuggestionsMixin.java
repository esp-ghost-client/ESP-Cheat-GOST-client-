/*
 * Copyright (c) 2014-2026 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.mixin.autocomplete;

import java.util.concurrent.CompletableFuture;

import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import com.mojang.brigadier.suggestion.Suggestions;

import net.minecraft.client.gui.components.CommandSuggestions;
import net.minecraft.client.gui.components.EditBox;
import net.wurstclient.WurstClient;
import net.wurstclient.hacks.AutoCompleteHack;

@Mixin(CommandSuggestions.class)
public abstract class CommandSuggestionsMixin
{
	@Shadow
	@Final
	private EditBox input;
	@Shadow
	private CompletableFuture<Suggestions> pendingSuggestions;
	
	@Inject(method = "updateCommandInfo()V", at = @At("TAIL"))
	private void onUpdateCommandInfo(CallbackInfo ci)
	{
		AutoCompleteHack autoComplete =
			WurstClient.INSTANCE.getHax().autoCompleteHack;
		if(!autoComplete.isEnabled())
			return;
		
		String draftMessage =
			input.getValue().substring(0, input.getCursorPosition());
		autoComplete.onRefresh(draftMessage, (builder, suggestion) -> {
			input.setSuggestion(suggestion);
			pendingSuggestions = builder.buildFuture();
			showSuggestions(false);
		});
	}
	
	@Shadow
	public abstract void showSuggestions(boolean narrateFirstSuggestion);
}
