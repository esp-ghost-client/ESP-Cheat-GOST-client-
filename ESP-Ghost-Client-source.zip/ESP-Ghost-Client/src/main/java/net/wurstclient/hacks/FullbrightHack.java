/*
 * Copyright (c) 2014-2026 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.hacks;

import net.minecraft.client.OptionInstance;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.wurstclient.Category;
import net.wurstclient.SearchTags;
import net.wurstclient.events.MobEffectListener;
import net.wurstclient.events.UpdateListener;
import net.wurstclient.hack.Hack;
import net.wurstclient.hacks.fullbright.BadOptimizationsLightmapHook;
import net.wurstclient.mixinterface.IOptionInstance;
import net.wurstclient.settings.CheckboxSetting;
import net.wurstclient.settings.EnumSetting;
import net.wurstclient.settings.SliderSetting;
import net.wurstclient.settings.SliderSetting.ValueDisplay;

@SearchTags({"Fullbrightness", "full brightness", "Fulbrightness",
	"ful brightness", "NightVision", "night vision", "FullLightness",
	"FulLightness", "full lightness", "FullGamma", "full gamma"})
public final class FullbrightHack extends Hack
	implements UpdateListener, MobEffectListener
{
	private final EnumSetting<Method> method = new EnumSetting<>("Method",
		"\u00a7lGamma\u00a7r works by setting your brightness slider beyond 100%. Incompatible with shader packs.\n\n"
			+ "\u00a7lNight Vision\u00a7r works by applying the night vision effect. This \u00a7ousually\u00a7r works with shader packs.",
		Method.values(), Method.GAMMA);
	
	private final CheckboxSetting fade = new CheckboxSetting("Fade",
		"Slowly fades between brightness and darkness.", true);
	
	private final SliderSetting defaultGamma = new SliderSetting(
		"Default brightness",
		"Fullbright will set your brightness slider back to this value when you turn it off.",
		0.5, 0, 1, 0.01, ValueDisplay.PERCENTAGE);
	
	private final MobEffectInstance nightVisionInstance =
		new MobEffectInstance(MobEffects.NIGHT_VISION,
			MobEffectInstance.INFINITE_DURATION, 0, false, false);
	
	private boolean wasGammaChanged;
	private float nightVisionStrength;
	
	public FullbrightHack()
	{
		super("Fullbright");
		setCategory(Category.RENDER);
		addSetting(method);
		addSetting(fade);
		addSetting(defaultGamma);
		
		checkGammaOnStartup();
		EVENTS.add(UpdateListener.class, this);
		EVENTS.add(MobEffectListener.class, this);
	}
	
	private void checkGammaOnStartup()
	{
		EVENTS.add(UpdateListener.class, new UpdateListener()
		{
			@Override
			public void onUpdate()
			{
				double gamma = MC.options.gamma().get();
				System.out.println("Brightness started at " + gamma);
				
				if(gamma > 1)
					wasGammaChanged = true;
				else
					defaultGamma.setValue(gamma);
				
				EVENTS.remove(UpdateListener.class, this);
			}
		});
	}
	
	public void turnOffInstantly()
	{
		setEnabled(false);
		
		if(wasGammaChanged)
		{
			IOptionInstance.get(MC.options.gamma())
				.forceSet(defaultGamma.getValue());
			wasGammaChanged = false;
		}
		
		nightVisionStrength = 0;
		BadOptimizationsLightmapHook.markForUpdate();
	}
	
	@Override
	public void onUpdate()
	{
		updateGamma();
		updateNightVision();
	}
	
	private void updateGamma()
	{
		if(isChangingGamma())
		{
			setGamma(16);
			return;
		}
		
		if(wasGammaChanged)
			resetGamma(defaultGamma.getValue());
	}
	
	private void setGamma(double target)
	{
		wasGammaChanged = true;
		
		OptionInstance<Double> gammaOption = MC.options.gamma();
		IOptionInstance<Double> gammaOption2 = IOptionInstance.get(gammaOption);
		double oldGammaValue = gammaOption.get();
		
		if(!fade.isChecked() || Math.abs(oldGammaValue - target) <= 0.5)
		{
			gammaOption2.forceSet(target);
			return;
		}
		
		if(oldGammaValue < target)
			gammaOption2.forceSet(oldGammaValue + 0.5);
		else
			gammaOption2.forceSet(oldGammaValue - 0.5);
	}
	
	private void resetGamma(double target)
	{
		OptionInstance<Double> gammaOption = MC.options.gamma();
		IOptionInstance<Double> gammaOption2 = IOptionInstance.get(gammaOption);
		double oldGammaValue = gammaOption.get();
		
		if(!fade.isChecked() || Math.abs(oldGammaValue - target) <= 0.5)
		{
			gammaOption2.forceSet(target);
			wasGammaChanged = false;
			return;
		}
		
		if(oldGammaValue < target)
			gammaOption2.forceSet(oldGammaValue + 0.5);
		else
			gammaOption2.forceSet(oldGammaValue - 0.5);
	}
	
	private void updateNightVision()
	{
		float oldNightVisionStrength = nightVisionStrength;
		boolean shouldGiveNightVision =
			isEnabled() && method.getSelected() == Method.NIGHT_VISION;
		
		if(fade.isChecked())
		{
			if(shouldGiveNightVision)
				nightVisionStrength += 0.03125;
			else
				nightVisionStrength -= 0.03125;
			
			nightVisionStrength = Math.clamp(nightVisionStrength, 0, 1);
			
		}else if(shouldGiveNightVision)
			nightVisionStrength = 1;
		else
			nightVisionStrength = 0;
		
		if(oldNightVisionStrength != nightVisionStrength)
			BadOptimizationsLightmapHook.markForUpdate();
	}
	
	@Override
	public void onMobEffect(MobEffectEvent event)
	{
		if(event.getEffect() == MobEffects.NIGHT_VISION
			&& nightVisionStrength > 0)
			event.setInstance(nightVisionInstance);
	}
	
	public float getNightVisionStrength()
	{
		return nightVisionStrength;
	}
	
	public boolean isChangingGamma()
	{
		return isEnabled() && method.getSelected() == Method.GAMMA;
	}
	
	/**
	 * Returns the value of Fullbright's "Default brightness" slider. Used by
	 * {@link XRayHack} to restore the gamma value when X-Ray is turned off.
	 */
	public double getDefaultGamma()
	{
		return defaultGamma.getValue();
	}
	
	private static enum Method
	{
		GAMMA("Gamma"),
		NIGHT_VISION("Night Vision");
		
		private final String name;
		
		private Method(String name)
		{
			this.name = name;
		}
		
		@Override
		public String toString()
		{
			return name;
		}
	}
}
