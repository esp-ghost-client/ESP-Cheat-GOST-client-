package bloodystar.espmenu;

import java.awt.Color;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;

import org.lwjgl.glfw.GLFW;

import net.minecraft.ChatFormatting;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.wurstclient.WurstClient;
import net.wurstclient.hack.Hack;
import net.wurstclient.hack.HackList;
import net.wurstclient.settings.CheckboxSetting;
import net.wurstclient.settings.ColorSetting;
import net.wurstclient.settings.EnumSetting;
import net.wurstclient.settings.Setting;
import net.wurstclient.settings.SliderSetting;

/**
 * Neon ESP-only menu. Tab 0 = master page, tabs 1..9 = one page per ESP.
 * Every setting is generated from the real Wurst settings, so nothing here
 * has to be updated when an ESP gets a new option.
 */
public final class EspMenuScreen extends Screen
{
	// ---- palette (ARGB) ----
	private static final int BG = 0xF00B0B14;
	private static final int CARD = 0xFF151522;
	private static final int CARD_HOVER = 0xFF1D1D2E;
	private static final int TEXT = 0xFFEDEDF7;
	private static final int DIM = 0xFF8C8CA6;
	private static final int GREEN = 0xFF35E06F;
	private static final int OFF = 0xFF3A3A50;
	
	private static final String MENU_TITLE = "ESP Ghost Client MC1.21.4 v1.0";
	private static final int SIDE = 100;
	private static final int TITLE = 30;
	
	private enum Type
	{
		HEADER,
		TOGGLE,
		ENUM,
		SLIDER,
		COLOR,
		BUTTON
	}
	
	private static final class Row
	{
		Type type;
		String label;
		int h;
		int y;
		Object key;
		BooleanSupplier get;
		Consumer<Boolean> set;
		EnumSetting<?> en;
		SliderSetting sl;
		ColorSetting col;
		Runnable action;
	}
	
	private final List<Hack> hacks = new ArrayList<>();
	/** Only ESPs that actually have options get their own tab. */
	private final List<Hack> tabHacks = new ArrayList<>();
	private final List<Row> rows = new ArrayList<>();
	private final Map<Object, Float> anims = new HashMap<>();
	
	private int tab;
	private float scroll;
	private int totalH;
	private Row dragRow;
	private int dragChan;
	
	private long lastNs = System.nanoTime();
	private float dt;
	private float open;
	
	private int px, py, pw, ph, cx, cy, cw, ch;
	
	public EspMenuScreen()
	{
		super(Component.literal("ESP Ghost Client MC1.21.4 v1.0"));
		HackList h = WurstClient.INSTANCE.getHax();
		Collections.addAll(hacks, h.chestEspHack, h.playerEspHack,
			h.mobEspHack, h.itemEspHack, h.portalEspHack, h.barrierEspHack,
			h.mobSpawnEspHack, h.openWaterEspHack, h.prophuntEspHack);
		
		for(Hack hack : hacks)
			if(hasMenuSettings(hack))
				tabHacks.add(hack);
	}
	
	private static boolean hasMenuSettings(Hack h)
	{
		for(Setting s : h.getSettings().values())
			if(s instanceof CheckboxSetting || s instanceof EnumSetting<?>
				|| s instanceof SliderSetting || s instanceof ColorSetting)
				return true;
		return false;
	}
	
	// ------------------------------------------------------------------
	// helpers
	// ------------------------------------------------------------------
	
	private float anim(Object key, float target)
	{
		float v = anims.getOrDefault(key, target);
		v += (target - v) * Math.min(1F, dt * 14F);
		anims.put(key, v);
		return v;
	}
	
	private static int lerp(int a, int b, float t)
	{
		t = Math.max(0F, Math.min(1F, t));
		int ar = a >> 16 & 255, ag = a >> 8 & 255, ab = a & 255;
		int br = b >> 16 & 255, bg = b >> 8 & 255, bb = b & 255;
		return 0xFF000000 | (int)(ar + (br - ar) * t) << 16
			| (int)(ag + (bg - ag) * t) << 8 | (int)(ab + (bb - ab) * t);
	}
	
	private static int accent()
	{
		float t = (float)(Math.sin(System.currentTimeMillis() / 900.0) * 0.5 + 0.5);
		return lerp(0xFF8A2BE2, 0xFFFF2D55, t);
	}
	
	private static int accent2()
	{
		float t = (float)(Math.cos(System.currentTimeMillis() / 900.0) * 0.5 + 0.5);
		return lerp(0xFF8A2BE2, 0xFFFF2D55, t);
	}
	
	private static void pill(GuiGraphics g, int x, int y, int w, int h, int c)
	{
		g.fill(x + 1, y, x + w - 1, y + h, c);
		g.fill(x, y + 1, x + w, y + h - 1, c);
	}
	
	private void text(GuiGraphics g, String s, int x, int y, int color)
	{
		g.drawString(font, s, x, y, color);
	}
	
	private int tw(String s)
	{
		return font.width(s);
	}
	
	private void geometry()
	{
		pw = Math.min(480, width - 12);
		ph = Math.min(290, height - 12);
		px = (width - pw) / 2;
		py = (height - ph) / 2 + (int)((1F - open) * 14F);
		cx = px + SIDE + 8;
		cy = py + TITLE + 6;
		cw = pw - SIDE - 16;
		ch = ph - TITLE - 12;
	}
	
	private int tabHeight()
	{
		return Math.min(22, (ph - TITLE - 12) / (tabHacks.size() + 1));
	}
	
	private String tabName(int i)
	{
		return i == 0 ? "ALL / MASTER" : tabHacks.get(i - 1).getName();
	}
	
	private void setAll(boolean on)
	{
		for(Hack h : hacks)
			h.setEnabled(on);
	}
	
	// ------------------------------------------------------------------
	// rows
	// ------------------------------------------------------------------
	
	private Row row(Type t, String label, int h, Object key)
	{
		Row r = new Row();
		r.type = t;
		r.label = label;
		r.h = h;
		r.key = key;
		return r;
	}
	
	private Row header(String label)
	{
		return row(Type.HEADER, label, 18, label);
	}
	
	private Row button(String label, Runnable action)
	{
		Row r = row(Type.BUTTON, label, 24, label);
		r.action = action;
		return r;
	}
	
	private Row toggle(String label, BooleanSupplier get,
		Consumer<Boolean> set, Object key)
	{
		Row r = row(Type.TOGGLE, label, 22, key);
		r.get = get;
		r.set = set;
		return r;
	}
	
	private void buildRows()
	{
		rows.clear();
		
		if(tab == 0)
		{
			rows.add(button("ENABLE ALL ESP", () -> setAll(true)));
			rows.add(button("DISABLE ALL ESP", () -> setAll(false)));
			rows.add(header("ESP MODULES"));
			for(Hack h : hacks)
				rows.add(toggle(h.getName(), h::isEnabled, h::setEnabled, h));
			
		}else
		{
			Hack h = tabHacks.get(tab - 1);
			rows.add(toggle("Enabled", h::isEnabled, h::setEnabled, h));
			rows.add(header("SETTINGS"));
			
			for(Setting s : h.getSettings().values())
			{
				if(s instanceof CheckboxSetting c)
					rows.add(toggle(c.getName(), c::isChecked, c::setChecked,
						c));
				else if(s instanceof EnumSetting<?> e)
				{
					Row r = row(Type.ENUM, e.getName(), 22, e);
					r.en = e;
					rows.add(r);
				}else if(s instanceof SliderSetting sl)
				{
					Row r = row(Type.SLIDER, sl.getName(), 30, sl);
					r.sl = sl;
					rows.add(r);
				}else if(s instanceof ColorSetting col)
				{
					Row r = row(Type.COLOR, col.getName(), 58, col);
					r.col = col;
					rows.add(r);
				}
			}
		}
		
		int y = 0;
		for(Row r : rows)
		{
			r.y = y;
			y += r.h;
		}
		totalH = y;
		
		float max = Math.max(0, totalH - ch);
		scroll = Math.max(0, Math.min(max, scroll));
	}
	
	// ------------------------------------------------------------------
	// rendering
	// ------------------------------------------------------------------
	
	@Override
	public void render(GuiGraphics g, int mx, int my, float partialTick)
	{
		long now = System.nanoTime();
		dt = Math.min(0.05F, (now - lastNs) / 1_000_000_000F);
		lastNs = now;
		open = anim("open", 1F);
		
		geometry();
		buildRows();
		
		int a1 = accent();
		int a2 = accent2();
		
		// dim the world
		g.fill(0, 0, width, height, 0x88000000);
		
		// glow + panel
		g.fill(px - 2, py - 2, px + pw + 2, py + ph + 2, 0x33000000 | (a1 & 0xFFFFFF));
		g.fill(px - 1, py - 1, px + pw + 1, py + ph + 1, a1);
		g.fill(px, py, px + pw, py + ph, BG);
		
		// animated gradient bar on top
		for(int x = 0; x < pw; x += 2)
			g.fill(px + x, py, Math.min(px + pw, px + x + 2), py + 2,
				lerp(a1, a2, x / (float)pw));
		
		// title
		g.drawString(font,
			Component.literal("ESP Ghost Client MC1.21.4 v1.0")
				.withStyle(ChatFormatting.BOLD),
			px + 10, py + 7, a1);
		text(g, "by ItsBloodyStar", px + 10, py + 18, DIM);
		
		// close button
		int bx = px + pw - 22, by = py + 8;
		boolean hClose = mx >= bx && mx < bx + 14 && my >= by && my < by + 14;
		pill(g, bx, by, 14, 14,
			lerp(CARD, 0xFFFF2D55, anim("close", hClose ? 1F : 0F)));
		text(g, "X", bx + 4, by + 3, TEXT);
		
		// sidebar
		g.fill(px, py + TITLE, px + SIDE, py + ph, 0xFF0F0F1A);
		int th = tabHeight();
		for(int i = 0; i <= tabHacks.size(); i++)
		{
			int ty = py + TITLE + 6 + i * th;
			boolean hover = mx >= px + 4 && mx < px + SIDE - 4 && my >= ty
				&& my < ty + th - 2;
			float sel = anim("tab" + i, i == tab ? 1F : hover ? 0.45F : 0F);
			
			pill(g, px + 4, ty, SIDE - 8, th - 2, lerp(0xFF0F0F1A, CARD_HOVER, sel));
			if(i == tab)
				g.fill(px + 4, ty + 3, px + 6, ty + th - 5, a1);
			
			boolean on = i == 0
				? hacks.stream().anyMatch(Hack::isEnabled)
				: tabHacks.get(i - 1).isEnabled();
			g.fill(px + SIDE - 14, ty + th / 2 - 3, px + SIDE - 9,
				ty + th / 2 + 2, on ? GREEN : OFF);
			
			text(g, tabName(i), px + 11, ty + (th - 10) / 2,
				lerp(DIM, TEXT, sel));
		}
		
		// content
		g.enableScissor(cx, cy, cx + cw, cy + ch);
		for(Row r : rows)
		{
			int ry = cy + r.y - (int)scroll;
			if(ry + r.h < cy || ry > cy + ch)
				continue;
			renderRow(g, r, ry, mx, my, a1, a2);
		}
		g.disableScissor();
		
		// scrollbar
		if(totalH > ch)
		{
			int sbH = Math.max(16, ch * ch / totalH);
			int sbY = cy + (int)((ch - sbH) * (scroll / (totalH - ch)));
			g.fill(cx + cw + 2, sbY, cx + cw + 4, sbY + sbH, a1);
		}
	}
	
	private void renderRow(GuiGraphics g, Row r, int ry, int mx, int my,
		int a1, int a2)
	{
		boolean inside = my >= cy && my < cy + ch;
		boolean hover = inside && mx >= cx && mx < cx + cw && my >= ry
			&& my < ry + r.h - 2;
		float hv = anim(r.type + "h" + System.identityHashCode(r.key) + r.label,
			hover ? 1F : 0F);
		int card = lerp(CARD, CARD_HOVER, hv);
		
		switch(r.type)
		{
			case HEADER:
			text(g, r.label, cx + 2, ry + 6, DIM);
			g.fill(cx + 4 + tw(r.label), ry + 10, cx + cw, ry + 11, 0xFF26263A);
			break;
			
			case BUTTON:
			pill(g, cx, ry, cw, r.h - 2, lerp(a1, a2, hv));
			pill(g, cx + 1, ry + 1, cw - 2, r.h - 4, lerp(0xFF12121E, card, hv));
			text(g, r.label, cx + (cw - tw(r.label)) / 2, ry + 7,
				lerp(TEXT, 0xFFFFFFFF, hv));
			break;
			
			case TOGGLE:
			{
				boolean on = r.get.getAsBoolean();
				float k = anim(System.identityHashCode(r.key) + r.label + "k",
					on ? 1F : 0F);
				pill(g, cx, ry, cw, r.h - 2, card);
				text(g, r.label, cx + 8, ry + 6, TEXT);
				int sx = cx + cw - 34, sy = ry + 4;
				pill(g, sx, sy, 26, 12, lerp(OFF, GREEN, k));
				pill(g, sx + 2 + (int)(14 * k), sy + 2, 8, 8, 0xFFFFFFFF);
				break;
			}
			
			case ENUM:
			{
				pill(g, cx, ry, cw, r.h - 2, card);
				text(g, r.label, cx + 8, ry + 6, TEXT);
				String v = "< " + r.en.getSelected() + " >";
				text(g, v, cx + cw - 8 - tw(v), ry + 6, a1);
				break;
			}
			
			case SLIDER:
			{
				SliderSetting s = r.sl;
				if(isDrag(r))
					setSlider(s, (float)(mx - (cx + 8)) / (cw - 16));
				
				double range = s.getMaximum() - s.getMinimum();
				float p = range <= 0 ? 0F
					: (float)((s.getValue() - s.getMinimum()) / range);
				p = Math.max(0F, Math.min(1F, p));
				float sp = anim(System.identityHashCode(r.key) + "s", p);
				
				pill(g, cx, ry, cw, r.h - 2, card);
				text(g, r.label, cx + 8, ry + 5, TEXT);
				String v = s.getValueString();
				text(g, v, cx + cw - 8 - tw(v), ry + 5, a1);
				
				int bx = cx + 8, bw = cw - 16, byy = ry + 19;
				g.fill(bx, byy, bx + bw, byy + 4, OFF);
				for(int x = 0; x < (int)(bw * sp); x += 2)
					g.fill(bx + x, byy, Math.min(bx + (int)(bw * sp), bx + x + 2),
						byy + 4, lerp(a1, a2, x / (float)bw));
				g.fill(bx + (int)(bw * sp) - 2, byy - 2, bx + (int)(bw * sp) + 2,
					byy + 6, 0xFFFFFFFF);
				break;
			}
			
			case COLOR:
			{
				ColorSetting s = r.col;
				if(isDrag(r))
					setChannel(s, dragChan, (float)(mx - (cx + 22)) / (cw - 30));
				
				Color c = s.getColor();
				pill(g, cx, ry, cw, r.h - 2, card);
				text(g, r.label, cx + 8, ry + 5, TEXT);
				pill(g, cx + cw - 30, ry + 4, 22, 10, 0xFF000000 | c.getRGB() & 0xFFFFFF);
				
				int[] vals = {c.getRed(), c.getGreen(), c.getBlue()};
				int[] cols = {0xFFFF4D4D, 0xFF4DFF6A, 0xFF4D7AFF};
				String[] names = {"R", "G", "B"};
				for(int i = 0; i < 3; i++)
				{
					int yy = ry + 19 + i * 12;
					text(g, names[i], cx + 8, yy - 3, cols[i]);
					int bx = cx + 22, bw = cw - 30;
					g.fill(bx, yy, bx + bw, yy + 4, OFF);
					int fw = (int)(bw * (vals[i] / 255F));
					g.fill(bx, yy, bx + fw, yy + 4, cols[i]);
					g.fill(bx + fw - 2, yy - 2, bx + fw + 2, yy + 6, 0xFFFFFFFF);
				}
				break;
			}
		}
	}
	
	/** Rows are rebuilt every frame, so compare by the setting they wrap. */
	private boolean isDrag(Row r)
	{
		return dragRow != null && dragRow.key == r.key && dragRow.type == r.type;
	}
	
	private void setSlider(SliderSetting s, float pct)
	{
		pct = Math.max(0F, Math.min(1F, pct));
		double v = s.getMinimum() + pct * (s.getMaximum() - s.getMinimum());
		double inc = s.getIncrement();
		if(inc > 0)
			v = Math.round((v - s.getMinimum()) / inc) * inc + s.getMinimum();
		s.setValue(v);
	}
	
	private void setChannel(ColorSetting s, int chan, float pct)
	{
		pct = Math.max(0F, Math.min(1F, pct));
		Color c = s.getColor();
		int[] v = {c.getRed(), c.getGreen(), c.getBlue()};
		v[chan] = Math.round(pct * 255F);
		s.setColor(new Color(v[0], v[1], v[2]));
	}
	
	// ------------------------------------------------------------------
	// input
	// ------------------------------------------------------------------
	
	@Override
	public boolean mouseClicked(double mouseX, double mouseY, int button)
	{
		double mx = mouseX;
		double my = mouseY;
		int btn = button;
		
		geometry();
		
		// close
		int bx = px + pw - 22, by = py + 8;
		if(mx >= bx && mx < bx + 14 && my >= by && my < by + 14)
		{
			onClose();
			return true;
		}
		
		// tabs
		int th = tabHeight();
		for(int i = 0; i <= tabHacks.size(); i++)
		{
			int ty = py + TITLE + 6 + i * th;
			if(mx >= px + 4 && mx < px + SIDE - 4 && my >= ty
				&& my < ty + th - 2)
			{
				if(tab != i)
				{
					tab = i;
					scroll = 0;
				}
				return true;
			}
		}
		
		// rows
		if(mx >= cx && mx < cx + cw && my >= cy && my < cy + ch)
		{
			buildRows();
			for(Row r : rows)
			{
				int ry = cy + r.y - (int)scroll;
				if(my < ry || my >= ry + r.h - 2)
					continue;
				
				switch(r.type)
				{
					case TOGGLE:
					r.set.accept(!r.get.getAsBoolean());
					return true;
					
					case ENUM:
					if(btn == 1)
						r.en.selectPrev();
					else
						r.en.selectNext();
					return true;
					
					case SLIDER:
					dragRow = r;
					return true;
					
					case COLOR:
					{
						int chan = (int)((my - (ry + 15)) / 12);
						if(chan >= 0 && chan <= 2)
						{
							dragRow = r;
							dragChan = chan;
						}
						return true;
					}
					
					case BUTTON:
					r.action.run();
					return true;
					
					default:
					return true;
				}
			}
		}
		
		return super.mouseClicked(mouseX, mouseY, button);
	}
	
	@Override
	public boolean mouseReleased(double mouseX, double mouseY, int button)
	{
		dragRow = null;
		return super.mouseReleased(mouseX, mouseY, button);
	}
	
	@Override
	public boolean mouseScrolled(double mouseX, double mouseY, double scrollX,
		double scrollY)
	{
		scroll -= (float)scrollY * 16F;
		float max = Math.max(0, totalH - ch);
		scroll = Math.max(0, Math.min(max, scroll));
		return true;
	}
	
	@Override
	public boolean keyPressed(int keyCode, int scanCode, int modifiers)
	{
		if(keyCode == GLFW.GLFW_KEY_0)
		{
			onClose();
			return true;
		}
		return super.keyPressed(keyCode, scanCode, modifiers);
	}
	
	@Override
	public boolean isPauseScreen()
	{
		return false;
	}
	
	@Override
	public void onClose()
	{
		EspMenuMod.lastClose = System.currentTimeMillis();
		super.onClose();
	}
}
