package bloodystar.espmenu;


import com.mojang.blaze3d.platform.InputConstants;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;

public final class EspMenuMod implements ClientModInitializer
{
	/** GLFW_KEY_0 (the 0 key on the top row). */
	private static final int KEY_0 = 48;
	
	/** Set by the screen when it closes, so the same key press can't reopen it. */
	public static volatile long lastClose;
	
	private boolean wasDown;
	
	@Override
	public void onInitializeClient()
	{
		ClientTickEvents.END_CLIENT_TICK.register(mc -> {
			boolean down = InputConstants.isKeyDown(KEY_0);
			
			boolean cooldown = System.currentTimeMillis() - lastClose < 400;
			if(down && !wasDown && !cooldown && mc.gui.screen() == null
				&& mc.player != null)
				mc.gui.setScreen(new EspMenuScreen());
			
			wasDown = down;
		});
	}
}
