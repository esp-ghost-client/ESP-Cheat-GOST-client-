package bloodystar.espmenu;

import org.lwjgl.glfw.GLFW;

import com.mojang.blaze3d.platform.InputConstants;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;

public final class EspMenuMod implements ClientModInitializer
{
	/** Set by the screen when it closes, so the same key press can't reopen it. */
	public static volatile long lastClose;
	
	private boolean wasDown;
	
	@Override
	public void onInitializeClient()
	{
		ClientTickEvents.END_CLIENT_TICK.register(mc -> {
			if(mc.getWindow() == null)
				return;
			
			boolean down = InputConstants.isKeyDown(mc.getWindow().getWindow(),
				GLFW.GLFW_KEY_0);
			
			boolean cooldown = System.currentTimeMillis() - lastClose < 400;
			if(down && !wasDown && !cooldown && mc.screen == null
				&& mc.player != null)
				mc.setScreen(new EspMenuScreen());
			
			wasDown = down;
		});
	}
}
