/*
 * Copyright (c) 2014-2026 Wurst-Imperium and contributors.
 *
 * This source code is subject to the terms of the GNU General Public
 * License, version 3. If a copy of the GPL was not distributed with this
 * file, You can obtain one at: https://www.gnu.org/licenses/gpl-3.0.txt
 */
package net.wurstclient.navigator;

import java.awt.Rectangle;
import java.util.ArrayList;

import org.lwjgl.glfw.GLFW;

import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;
import net.wurstclient.Feature;
import net.wurstclient.WurstClient;
import net.wurstclient.clickgui.ClickGui;
import net.wurstclient.clickgui.ClickGuiIcons;
import net.wurstclient.hacks.TooManyHaxHack;
import net.wurstclient.util.ChatUtils;
import net.wurstclient.util.RenderUtils;

public final class NavigatorMainScreen extends NavigatorScreen
{
	private static final ArrayList<Feature> navigatorDisplayList =
		new ArrayList<>();
	private EditBox searchBar;
	private String lastSearchText = "";
	private String tooltip;
	private int hoveredFeature = -1;
	private int selectedFeature = 0;
	private boolean mouseMoved = false;
	private boolean hoveringArrow;
	private int clickTimer = -1;
	private boolean expanding = false;
	private Feature expandingFeature;
	
	public NavigatorMainScreen()
	{
		hasBackground = false;
		nonScrollableArea = 0;
		
		Navigator navigator = WurstClient.INSTANCE.getNavigator();
		navigator.copyNavigatorList(navigatorDisplayList);
	}
	
	@Override
	protected void onResize()
	{
		ClickGui gui = WurstClient.INSTANCE.getGui();
		int txtColor = gui.getTxtColor();
		
		Font tr = WurstClient.MC.font;
		searchBar = new EditBox(tr, 0, 32, 200, 20, Component.literal(""));
		searchBar.setTextColor(txtColor);
		searchBar.setBordered(false);
		searchBar.setMaxLength(128);
		
		addWidget(searchBar);
		setFocused(searchBar);
		searchBar.setFocused(true);
		
		searchBar.setX(middleX - 100);
		setContentHeight(navigatorDisplayList.size() / 3 * 20);
	}
	
	@Override
	protected void onKeyPress(KeyEvent context)
	{
		int keyCode = context.key();
		boolean hasShiftDown = context.hasShiftDown();
		
		if(keyCode == GLFW.GLFW_KEY_ENTER)
			leftClick(selectedFeature);
		
		if(keyCode == GLFW.GLFW_KEY_SPACE)
			expand(selectedFeature);
		
		if(keyCode == GLFW.GLFW_KEY_RIGHT
			|| keyCode == GLFW.GLFW_KEY_TAB && !hasShiftDown)
		{
			if(selectedFeature + 1 < navigatorDisplayList.size())
				selectedFeature++;
			
		}else if(keyCode == GLFW.GLFW_KEY_LEFT
			|| keyCode == GLFW.GLFW_KEY_TAB && hasShiftDown)
		{
			if(selectedFeature - 1 > -1)
				selectedFeature--;
			
		}else if(keyCode == GLFW.GLFW_KEY_DOWN)
		{
			if(selectedFeature + 3 < navigatorDisplayList.size())
				selectedFeature += 3;
			
		}else if(keyCode == GLFW.GLFW_KEY_UP)
			if(selectedFeature - 3 > -1)
				selectedFeature -= 3;
	}
	
	@Override
	protected void onMouseClick(MouseButtonEvent context)
	{
		int button = context.button();
		boolean hasShiftDown = context.hasShiftDown();
		
		if(clickTimer != -1)
			return;
		
		// back button
		if(button == GLFW.GLFW_MOUSE_BUTTON_4)
		{
			WurstClient.MC.setScreen((Screen)null);
			return;
		}
		
		if(hoveredFeature == -1)
			return;
		
		// arrow click, shift click, wheel click
		if(button == GLFW.GLFW_MOUSE_BUTTON_LEFT
			&& (hasShiftDown || hoveringArrow)
			|| button == GLFW.GLFW_MOUSE_BUTTON_MIDDLE)
		{
			expand(hoveredFeature);
			return;
		}
		
		// left click
		if(button == GLFW.GLFW_MOUSE_BUTTON_LEFT)
			leftClick(hoveredFeature);
	}
	
	private void expand(int i)
	{
		if(i < 0 || i >= navigatorDisplayList.size())
			return;
		
		expandingFeature = navigatorDisplayList.get(i);
		expanding = true;
	}
	
	private void leftClick(int i)
	{
		if(i < 0 || i >= navigatorDisplayList.size())
			return;
		
		Feature feature = navigatorDisplayList.get(i);
		
		if(feature.getPrimaryAction().isEmpty())
		{
			expanding = true;
			expandingFeature = feature;
			return;
		}
		
		WurstClient wurst = WurstClient.INSTANCE;
		TooManyHaxHack tooManyHax = wurst.getHax().tooManyHaxHack;
		
		if(tooManyHax.isEnabled() && tooManyHax.isBlocked(feature))
		{
			ChatUtils.error(feature.getName() + " is blocked by TooManyHax.");
			return;
		}
		
		feature.doPrimaryAction();
		wurst.getNavigator().addPreference(feature.getName());
	}
	
	@Override
	protected void onUpdate()
	{
		String newText = searchBar.getValue();
		if(clickTimer == -1 && !newText.equals(lastSearchText))
		{
			Navigator navigator = WurstClient.INSTANCE.getNavigator();
			
			if(newText.isEmpty())
				navigator.copyNavigatorList(navigatorDisplayList);
			else
			{
				newText = newText.toLowerCase().trim();
				navigator.getSearchResults(navigatorDisplayList, newText);
			}
			
			setContentHeight(navigatorDisplayList.size() / 3 * 20);
			lastSearchText = newText;
			selectedFeature = 0;
		}
		
		if(expanding)
			if(clickTimer < 4)
				clickTimer++;
			else
				WurstClient.MC.setScreen(
					new NavigatorFeatureScreen(expandingFeature, this));
		else if(!expanding && clickTimer > -1)
			clickTimer--;
		
		scrollbarLocked = clickTimer != -1;
	}
	
	@Override
	public void mouseMoved(double mouseX, double mouseY)
	{
		mouseMoved = true;
	}
	
	@Override
	protected void onRender(GuiGraphics graphics, int mouseX, int mouseY,
		float partialTicks)
	{
		ClickGui gui = WurstClient.INSTANCE.getGui();
		int txtColor = gui.getTxtColor();
		
		boolean clickTimerRunning = clickTimer != -1;
		tooltip = null;
		
		// search bar
		if(!clickTimerRunning)
		{
			graphics.drawString(WurstClient.MC.font, "Search: ", middleX - 150,
				32, txtColor);
			searchBar.render(graphics, mouseX, mouseY, partialTicks);
		}
		
		// feature list
		int listX = middleX - 154;
		if(!clickTimerRunning)
			hoveredFeature = -1;
		
		graphics.enableScissor(0, 59, width, height - 42);
		
		for(int i = Math.max(-scroll * 3 / 20 - 3, 0); i < navigatorDisplayList
			.size(); i++)
		{
			int featureX = listX + 104 * (i % 3);
			int featureY = 60 + i / 3 * 20 + scroll;
			
			if(featureY < 40)
				continue;
			if(featureY > height - 40)
				break;
			
			renderFeature(graphics, mouseX, mouseY, partialTicks, i, featureX,
				featureY);
		}
		
		graphics.disableScissor();
		
		// tooltip
		if(tooltip != null)
		{
			graphics.guiRenderState.up();
			
			String[] lines = tooltip.split("\n");
			Font tr = minecraft.font;
			
			int tw = 0;
			int th = lines.length * tr.lineHeight;
			for(String line : lines)
			{
				int lw = tr.width(line);
				if(lw > tw)
					tw = lw;
			}
			int sw = minecraft.screen.width;
			int sh = minecraft.screen.height;
			
			int xt1 = mouseX + tw + 11 <= sw ? mouseX + 8 : mouseX - tw - 8;
			int xt2 = xt1 + tw + 3;
			int yt1 = mouseY + th - 2 <= sh ? mouseY - 4 : mouseY - th - 4;
			int yt2 = yt1 + th + 2;
			
			// background
			int bgColor = RenderUtils.toIntColor(gui.getBgColor(),
				gui.getTooltipOpacity());
			graphics.fill(xt1, yt1, xt2, yt2, bgColor);
			
			// outline
			int acColor = RenderUtils.toIntColor(gui.getAcColor(), 0.5F);
			RenderUtils.drawBorder2D(graphics, xt1, yt1, xt2, yt2, acColor);
			
			// text
			graphics.guiRenderState.up();
			for(int i = 0; i < lines.length; i++)
				graphics.drawString(tr, lines[i], xt1 + 2,
					yt1 + 2 + i * tr.lineHeight, txtColor, false);
		}
	}
	
	private void renderFeature(GuiGraphics graphics, int mouseX, int mouseY,
		float partialTicks, int i, int x, int y)
	{
		ClickGui gui = WurstClient.INSTANCE.getGui();
		boolean clickTimerRunning = clickTimer != -1;
		
		Feature feature = navigatorDisplayList.get(i);
		Rectangle area = new Rectangle(x, y, 100, 16);
		
		// click animation
		if(clickTimerRunning)
		{
			if(feature != expandingFeature)
				return;
			
			float factor;
			if(expanding)
				if(clickTimer == 4)
					factor = 1F;
				else
					factor = (clickTimer + partialTicks) / 4F;
			else if(clickTimer == 0)
				factor = 0F;
			else
				factor = (clickTimer - partialTicks) / 4F;
			float antiFactor = 1 - factor;
			
			area.x = (int)(area.x * antiFactor + (middleX - 154) * factor);
			area.y = (int)(area.y * antiFactor + 60 * factor);
			area.width = (int)(area.width * antiFactor + 308 * factor);
			area.height =
				(int)(area.height * antiFactor + (height - 103) * factor);
			
			drawBackgroundBox(graphics, area.x, area.y, area.x + area.width,
				area.y + area.height);
			return;
		}
		
		boolean hovering = area.contains(mouseX, mouseY);
		if(hovering)
		{
			hoveredFeature = i;
			
			if(mouseMoved)
			{
				selectedFeature = i;
				mouseMoved = false;
			}
		}
		
		boolean renderAsHovered = hovering || selectedFeature == i;
		
		// tooltip
		if(hovering)
			tooltip = feature.getWrappedDescription(200);
		
		// box & shadow
		int featColor = RenderUtils.toIntColor(
			feature.isEnabled() ? new float[]{0, 1, 0} : gui.getBgColor(),
			gui.getOpacity() * (renderAsHovered ? 1.5F : 1));
		drawBox(graphics, area.x, area.y, area.x + area.width,
			area.y + area.height, featColor);
		
		// separator
		int bx1 = area.x + area.width - area.height;
		int by1 = area.y + 2;
		int by2 = by1 + area.height - 4;
		int sepColor = RenderUtils.toIntColor(gui.getAcColor(), 0.5F);
		RenderUtils.drawLine2D(graphics, bx1, by1, bx1, by2, sepColor);
		
		// hovering
		if(hovering)
			hoveringArrow = mouseX >= bx1;
		
		graphics.guiRenderState.up();
		
		// arrow
		ClickGuiIcons.drawMinimizeArrow(graphics, bx1 + 2, area.y + 2.5F,
			area.x + area.width - 2, area.y + area.height - 3, hovering, true);
		
		// text
		if(!clickTimerRunning)
		{
			Font tr = minecraft.font;
			String buttonText = feature.getName();
			int bx = area.x + 4;
			int by = area.y + 4;
			int txtColor = gui.getTxtColor();
			graphics.drawString(tr, buttonText, bx, by, txtColor, false);
		}
	}
	
	public void setExpanding(boolean expanding)
	{
		this.expanding = expanding;
	}
	
	@Override
	protected void onMouseDrag(double mouseX, double mouseY, int button,
		double double_3, double double_4)
	{
		
	}
	
	@Override
	protected void onMouseRelease(double x, double y, int button)
	{
		
	}
}
