# ESP Ghost Client

Folders: v1_21_4, v1_21_8, v1_21_11, v26_3 (menu key in game: 0).
Each Actions run builds 4 zips (client jar + matching Fabric API jar) and publishes them
as a public release with the fixed tag "latest".

Direct download links (replace OWNER/REPO):
https://github.com/OWNER/REPO/releases/download/latest/ESP-Ghost-Client-MC1.21.4.zip
https://github.com/OWNER/REPO/releases/download/latest/ESP-Ghost-Client-MC1.21.8.zip
https://github.com/OWNER/REPO/releases/download/latest/ESP-Ghost-Client-MC1.21.11.zip
https://github.com/OWNER/REPO/releases/download/latest/ESP-Ghost-Client-MC26.3.zip

Based on Wurst Client (GPL-3.0).
