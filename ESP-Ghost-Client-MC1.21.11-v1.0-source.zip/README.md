# ESP Ghost Client MC1.21.11 v1.0 (menu update) (by ItsBloodyStar | mine_star777 | CMD Team)

Neon menu for ESP Ghost Client (MC 1.21.11). Open/close: 0 (zero).
Needs `ESP-Ghost-Client` jar + Fabric API in the mods folder.

Build: push this folder to GitHub, open Actions, download the `ESP-Ghost-Client` artifact.
